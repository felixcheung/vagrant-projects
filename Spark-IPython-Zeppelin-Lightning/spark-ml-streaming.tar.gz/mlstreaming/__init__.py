from mlstreaming.base import StreamingDemo

__version__ = '0.1.0'